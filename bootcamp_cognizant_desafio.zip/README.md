# Análise de dados com Python e Pandas:snake:





###  Olá ! Seja muito Bem-vindo (a) ao nosso repositório para iniciantes com base nas aulas da Prof. Fernanda Santos (Cientista de Dados) do (Desafio de projeto - Digital Innovation One)

###                    Bootcamp: Cognizant Cloud Data Engineer

### 	 

#### <u>**Repositório composto por:**</u>

- #### Datasets 

- #### Notebooks

- #### Estudo de Caso ( Análise exploratória na base de dados AdventureWorks)

- #### ***Bônus Especial ( Estudo de Caso - Análise Quanti - Ativos Bancários)*** em que se utilizou a biblioteca pandas voltado para o mercado financeiro 

  

#### **<u>Objetivos do repositório:</u>** 

1. #####   Apresentar a biblioteca Pandas

2. #####   Mostrar os principais métodos da biblioteca

3. #####   Apresentar um estudo de caso (Análise Exploratória na base de dados AdventureWorks)

   

#### **<u>Requisitos Básicos:</u>**

- ##### Utilização do Google Colab [](https://colab.research.google.com/) 

- ##### Vontade de Aprender

- ##### Vontade para colaborar com esse repositório 





#### **<u>Introdução:</u>**

- ###### <u>**DATA SCIENCE :**</u> É uma ciência que estuda as informações, seu processo de captura, transformação, geração, e posteriormente, análise de dados.

- ###### <u>LINGUAGEM DE PROGRAMAÇÃO:</u>  É uma linguagem formal que você utiliza uma série de instruções para comunicar com o computador. Desta forma, existem várias linguagens de programação , atualmente,  umas mais simples e outras mais complexas. As linguagens mais utilizadas no mercado atual são: Python e a linguagem R.

- ###### <u>BIBLIOTECA PANDAS:</u> Pandas é uma biblioteca de código aberto para análise de dados. Ela disponibiliza ao Python para trabalhar com dados tipo planilhas. Em face disso,  podemos carregar, manipular, alinhar e combinar dados entre outras funções.

  

## **Just start** :rocket:



